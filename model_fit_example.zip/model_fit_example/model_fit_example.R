
#PURPOSE: fitting linear and non-linear model example
#created: 4 October 2020 by Kelly Robinson

# The example shows how to fit different models to the same data and compare which model fits best for
# three different types of plankton groups. 'Best' fit is based on the amount of variance explained 
# (quantified by the R-square value) and the complexity of the model (i.e., the number of coefficients). 
# If the model R-square values are close, then always pick the simpler model (i.e., the one with fewest 
# coefficients).

library(tidyverse)
library(plyr)
library(stats)

#load example data set
load("model_fit_data.Rdata")

#run linear & non-linear models and compare fits for three different taxa

#ctenophore_cydippid ---------
cc <- pm[pm$group=="ctenophore_cydippid",]

p <- ggplot(data = cc,
             aes(x = tran.density.m3, y = patch.tran.total, color = patch.density)) +
  geom_smooth(method = "gam", color="black",fill="grey65") +
  geom_line(stat="smooth",method="gam", alpha=0.4) +
  geom_point(alpha=0.75) +
  geom_point(alpha=0.75, shape=1,colour="black") +
  scale_y_continuous(name = " patch count") +
  scale_x_continuous(name = "transect.density.m3")

y <- cc$patch.tran.total
x <- cc$tran.density.m3
#linear model
fit  <- lm(formula = y~x)
plot(fit)
summary(fit)
r2.fit <- summary(fit)$r.squared


#polynomial 2nd degree
fit2 <- lm(formula = y~poly(x,2,raw=TRUE))
plot(fit2)
summary(fit2)
r2.fit2 <- summary(fit2)$r.squared


#polynomial 3 degree
fit3 <- lm(y~poly(x,3,raw=TRUE))
summary(fit3)
r2.fit3 <- summary(fit3)$r.squared

#visually compare model fits
plot(x = x, y = y, pch=19)
lines(0:5, predict(fit, data.frame(x=0:5)), col="red")
lines(0:5, predict(fit2, data.frame(x=0:5)), col="blue")
lines(0:5, predict(fit3, data.frame(x=0:5)), col="green")

#compare R squared values
print(r2.fit); print(r2.fit2); print(r2.fit3)
# lm (fit) is the best model

a <- anova(fit)
cf <- coef(fit)

stats_cc <- broom::tidy(a)
stats_cc$group <- unique(cc$group)
stats_cc$x_term <- "tran.density.m3"
stats_cc$y_term <- "patch.tran.total"
stats_cc$intercept <- cf[1]
stats_cc$x_coef1 <- cf[2]
stats_cc$x_coef2 <- cf[3]
stats_cc$x_coef3 <- cf[4]
stats_cc$x_coef4 <- cf[5]
stats_cc

#write.csv(x = stats, file="manuscript_patch_scale/Fig5_stats.csv", row.names = F)

#crustacean_other ---------
co <- pm[pm$group=="crustacean_other",]

p <- ggplot(data = co,
            aes(x = tran.density.m3, y = patch.tran.total, color = patch.density)) +
  geom_smooth(method = "gam", color="black",fill="grey65") +
  geom_line(stat="smooth",method="gam", alpha=0.4) +
  geom_point(alpha=0.75) +
  geom_point(alpha=0.75, shape=1,colour="black") +
  scale_y_continuous(name = " patch count") +
  scale_x_continuous(name = "transect.density.m3")
p

y <- co$patch.tran.total
x <- co$tran.density.m3

#linear model
fit  <- lm(formula = y~x)
#plot(fit)
summary(fit)
r2.fit <- summary(fit)$r.squared
r2.fit

#polynomial 2nd degree
fit2 <- lm(formula = y~poly(x,2,raw=TRUE))
#plot(fit2)
summary(fit2)
r2.fit2 <- summary(fit2)$r.squared
r2.fit2

#polynomial 3 degree
fit3 <- lm(y~poly(x,3,raw=TRUE))
summary(fit3)
r2.fit3 <- summary(fit3)$r.squared
r2.fit3

#visually compare model fits
plot(x = x, y = y, pch=19)
lines(0:11, predict(fit, data.frame(x=0:11)), col="red")
lines(0:11, predict(fit2, data.frame(x=0:11)), col="blue")
lines(0:11, predict(fit3, data.frame(x=0:11)), col="green")

comp1 <- anova(fit,fit2); comp1 #fit2 (poly 2nd deg) better than fit (linear model)
comp2 <- anova(fit2,fit3); comp2 #no difference between fit2 (poly 2nd deg) and fit3 (poly 3rd deg)

#compare R squared values
print(r2.fit); print(r2.fit2); print(r2.fit3)
# poly 2nd deg (fit2) is the best model

#use fit 2(poly 2nd deg)
a <- anova(fit2)
cf <- coef(fit2)

stats_co <- broom::tidy(a)
stats_co$group <- unique(co$group)
stats_co$x_term <- "tran.density.m3"
stats_co$y_term <- "patch.tran.total"
stats_co$intercept <- cf[1]
stats_co$x_coef1 <- cf[2]
stats_co$x_coef2 <- cf[3]
stats_co$x_coef3 <- cf[4]
stats_co$x_coef4 <- cf[5]
stats_co


#fish----
f <- pm[pm$group=="fish",]


p <- ggplot(data = f,
            aes(x = tran.density.m3, y = patch.tran.total, color = patch.density)) +
  geom_smooth(method = "gam", color="black",fill="grey65") +
  geom_line(stat="smooth",method="gam", alpha=0.4) +
  geom_point(alpha=0.75) +
  geom_point(alpha=0.75, shape=1,colour="black") +
  scale_y_continuous(name = " patch count") +
  scale_x_continuous(name = "transect.density.m3")
p

y <- f$patch.tran.total
x <- f$tran.density.m3

#linear model
fit  <- lm(formula = y~x)
#plot(fit)
summary(fit)
r2.fit <- summary(fit)$r.squared
r2.fit

#polynomial 2nd degree
fit2 <- lm(formula = y~poly(x,2,raw=TRUE))
#plot(fit2)
summary(fit2)
r2.fit2 <- summary(fit2)$r.squared
r2.fit2

#polynomial 3 degree
fit3 <- lm(y~poly(x,3,raw=TRUE))
summary(fit3)
r2.fit3 <- summary(fit3)$r.squared
r2.fit3

#fourth degree
fit4 <- lm(y~poly(x,4,raw=TRUE))
summary(fit4)
r2.fit4 <- summary(fit4)$r.squared
r2.fit4

#visually compare model fits
plot(x = x, y = y, pch=19)
lines(0:5, predict(fit, data.frame(x=0:5)), col="red")
lines(0:5, predict(fit2, data.frame(x=0:5)), col="blue")
lines(0:5, predict(fit3, data.frame(x=0:5)), col="green")
lines(0:5, predict(fit4, data.frame(x=0:5)), col="purple")


comp1 <- anova(fit,fit2); comp1 #no difference fit2 (poly 2nd deg) & fit (linear model)
comp2 <- anova(fit2,fit3); comp2 #no difference fit3 (poly 2nd deg) & fit2 (poly 3rd deg)
comp3 <- anova(fit3,fit4); comp3 ##no difference fit4 (poly 4th deg) & fit3 (poly 3rd deg)

#compare R squared values
print(r2.fit); print(r2.fit2); print(r2.fit3); print(r2.fit4)
# linear model (fit) is the best model

#use # poly 4th deg (fit4)
a <- anova(fit)
cf <- coef(fit)

stats_f <- broom::tidy(a)
stats_f$group <- unique(f$group)
stats_f$x_term <- "tran.density.m3"
stats_f$y_term <- "patch.tran.total"
stats_f$intercept <- cf[1]
stats_f$x_coef1 <- cf[2]
stats_f$x_coef2 <- cf[3]
stats_f$x_coef3 <- cf[4]
stats_f$x_coef4 <- cf[5]
stats_f



#merge stats data frames for output----
stat_table <- rbind(stats_cc, stats_co, stats_f)

#save combined data frame to a .csv file
file = paste0("model_fit_example_stats.csv")
write.csv(x = stat_table, file=file)
