#Exercise #5

#Practice the following skills:
  # "adply" function
  # functions in the 'apply' family
  # summarizing data using 'aggregate' and 'summarize'

#Part 1: 'adply' function ----

#1) Read in and combine all the data in the .Rdata files found in the 'e5_data_sets' folder.
## Return a single data frame containing data from all the files.


#2) Read in and combine all the data in the .CSV files found in the 'e5_data_sets' folder.
## Return a single data frame containing data from all the files. Show

#Part 2: the #apply function family ----
#use when applying a function to a matrix or an array

#3) create a 8x5 matrix using the 'sea.monsters' object and a sequence of numbers that increases by 2 from 2 to 80
sea.monsters <- c("kraken","serpent","sirens","mermaids","nessy")

#4) find the standard error for all the columns in matrix created Question 3
std.error <- function(x){sd(x)/sqrt(length(x))}


#5) find the quantiles for all the columns in matrix created in Question 3


#6) find the row sums in matrix created in Question 3


# Generate a 5x7 array with 3 levels


#7) find the z-score of the rows
z.score <- function(x){
  z <- (x - mean(x))/sd(x)
  return(z)
}


#8) find the 95% confidence interval of the array's columns
CI95 <- function(y){
 error <- qt(0.975, df=length(y)-1)*sd(y)/sqrt(length(y))
 L95 <- list(L95=mean(y) - error)
 U95 <- list(U95=mean(y) + error)
 ci <- list(L95,U95)
 return(ci)
 }


#9) #please use the 'little_ost2014_physical.Rdata" data set for the following question
# find the standard error of the columns: temp, salinity, and pressure.
# You may need to subset these columns from the main data frame before summarizing and omit 'NA' values.


#Part 2: summarize and aggregate functions -----
#please use the 'little_ost2014_physical.Rdata" data set for the following questions

#10) Find the mean and standard deviation of depth; group by 'transect.id'


#11) use the functions 'group_by' and 'summarise' to generate the following summary statistics for the "temp" in a single data frame.
# Excluding the 'und' tows from your summary, group by 'tow' column.

